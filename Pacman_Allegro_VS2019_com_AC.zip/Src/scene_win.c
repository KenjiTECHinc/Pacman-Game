#define _CRT_SECURE_NO_WARNINGS


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_native_dialog.h>
#include <math.h>
#include "scene_menu_object.h"
#include "scene_settings.h"
#include "scene_game.h"
#include "scene_menu.h"
#include "utility.h"
#include "shared.h"

// Variables and functions with 'static' prefix at the top level of a
// source file is only accessible in that file ("file scope", also
// known as "internal linkage"). If other files has the same variable
// name, they'll be different variables.

/* Define your static vars / function prototypes below. */

// TODO: More variables and functions that will only be accessed
// inside this scene. They should all have the 'static' prefix.
//file settings
static ALLEGRO_SAMPLE_ID WinBGM;
static Button btnHome;
static Button btnReplay;
FILE* HFile;
char hscore[9];
char score[9];

static void init() {
	stop_bgm(WinBGM);
	WinBGM = play_bgm(themeMusic2, music_volume);
	HFile = fopen("Assets/Highscore.txt", "r");
	fgets(hscore, 9, HFile);
	btnReplay = button_create((SCREEN_W / 2) -134, (SCREEN_H / 2)+100, 64, 64, "Assets/Buttons/replay.png", "Assets/Buttons/replay2.png");
	btnHome = button_create((SCREEN_W / 2) +70, (SCREEN_H / 2)+100, 64, 64, "Assets/Buttons/to_home.png", "Assets/Buttons/to_home2.png");
}

static void draw(void ){
	al_clear_to_color(al_map_rgb(0, 0, 0));
	al_draw_text(hugeFont, al_map_rgb(255, 223, 0), SCREEN_W / 2, 200, ALLEGRO_ALIGN_CENTER, "YOU WIN!");
	drawButton(btnReplay);
	drawButton(btnHome);
	/*if (score >= hscore) {
		al_draw_text(menuFont, al_map_rgb(255, 223, 0), SCREEN_W / 2, 250, ALLEGRO_ALIGN_CENTER, "New Highscore! Congratulations!");
	}*/

	al_draw_text(menuFont, al_map_rgb(255, 223, 0), (SCREEN_W / 2) + 200, 300, ALLEGRO_ALIGN_RIGHT, hscore);
	al_draw_text(menuFont, al_map_rgb(255, 255, 255), (SCREEN_W / 2) - 200, 300, ALLEGRO_ALIGN_LEFT, "Highscore:");
	al_draw_text(menuFont, al_map_rgb(255, 255, 255), (SCREEN_W / 2) + 200, 350, ALLEGRO_ALIGN_RIGHT, score);
	al_draw_text(menuFont, al_map_rgb(255, 255, 255), (SCREEN_W / 2) - 145, 350, ALLEGRO_ALIGN_LEFT, "Score:");
}

static void on_mouse_move(int a, int mouse_x, int mouse_y, int f) {
	btnReplay.hovered = buttonHover(btnReplay, mouse_x, mouse_y);
	btnHome.hovered = buttonHover(btnHome, mouse_x, mouse_y);
}

static void on_mouse_down() {
	if (btnReplay.hovered) {
		game_change_scene(scene_main_create());
	}
	if (btnHome.hovered) {
		game_change_scene(scene_menu_create());
	}
}

static void destroy() {
	stop_bgm(WinBGM);

	al_destroy_bitmap(btnReplay.default_img);
	al_destroy_bitmap(btnReplay.hovered_img);

	al_destroy_bitmap(btnHome.default_img);
	al_destroy_bitmap(btnHome.hovered_img);
	fclose(HFile);
}
// The only function that is shared across files.
Scene scene_win_create(void) {
	Scene scene;
	memset(&scene, 0, sizeof(Scene));
	scene.name = "Win";
	scene.draw = &draw;
	scene.initialize = &init;
	scene.destroy = &destroy;
	//scene.on_key_down = &on_key_down;
	scene.on_mouse_down = &on_mouse_down;
	scene.on_mouse_move = &on_mouse_move;
	// TODO: Register more event callback functions such as keyboard, mouse, ...
	game_log("Win scene created");
	return scene;
}