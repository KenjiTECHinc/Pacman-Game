#ifndef SCENE_SETTINGS_H
#define SCENE_SETTINGS_H
//#define _CRT_SECURE_NO_WARNINGS
#include "game.h"

Scene scene_settings_create(void);

#endif
