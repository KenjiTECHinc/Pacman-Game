#define _CRT_SECURE_NO_WARNINGS

#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "game.h"
#include "shared.h"
#include "utility.h"
#include "scene_game.h"
#include "scene_menu.h"
#include "scene_gameover.h"
#include "scene_win.h"
#include "scene_menu_object.h"
#include "scene_settings.h"
#include "scene_win.h"
#include "pacman_obj.h"
#include "ghost.h"
#include "map.h"
#include "scene_achievement.h"

//map
extern ALLEGRO_TIMER* sandmaptimer;
//scores system
extern char score[9];
extern char hscore[9];
extern FILE* HFile = NULL;
static ALLEGRO_BITMAP* trophy;
// [HACKATHON 2-0]
// Just modify the GHOST_NUM to 1
#define GHOST_NUM 4 
/* global variables*/
extern const uint32_t GAME_TICK_CD;
extern uint32_t GAME_TICK;
extern ALLEGRO_TIMER* game_tick_timer;
int game_main_Score = 0;
bool game_over = false;
bool game_win = false;

// timer power bean
static ALLEGRO_TIMER* power_up_timer;
static const int power_up_duration = 10;
//invisible
static ALLEGRO_TIMER* invisible_timer;
static const int invisible_duration = 6;
//freeze speed
static ALLEGRO_TIMER* freeze_speed_timer;
static const int freeze_speed_duration = 9;

static Pacman* pman;
static Map* basic_map;
static Ghost** ghosts;
bool debug_mode = false;
bool cheat_mode = false;
//ghosters blinking
extern int GFlag = 0;
extern int IFlag = 0; //invisibility flag.
extern int FFlag = 0;

//Game pause
static Button btnPause;
static int PFlag=0;
static Button btnPlay;
static Button btnHome;
static Button btnRestart;
static Button btnSetting;

//achievement 1 function
FILE* a1FILE;
char one_status[128];
char one_temp[128];

/* Declare static function prototypes */
static void init(void);
static void step(void);
static void checkItem(void);
static void status_update(void);
static void update(void);
static void draw(void);
static void printinfo(void);
static void destroy(void);
static void on_key_down(int key_code);
static void on_mouse_down(void);
static void render_init_screen(void);
static void draw_hitboxes(void);
static void volume_update(void);

static void init(void) {
	game_over = false;
	game_main_Score = 0;
	// create map
	basic_map = create_map("Assets/map_nthu.txt");
	
	if (!basic_map) {
		game_abort("error on creating map");
	}	
	// create pacman
	pman = pacman_create();
	if (!pman) {
		game_abort("error on creating pacamn\n");
	}
	//bitmaps
	trophy = load_bitmap("Assets/Pics/Trophy.png");
	//Buttons
	btnPause = button_create(SCREEN_W - 63, 10, 38, 38, "Assets/Buttons/Pause.png", "Assets/Buttons/Pause2.png");
	btnSetting = button_create(SCREEN_W - 63, 10, 38, 38, "Assets/Buttons/setting.png", "Assets/Buttons/setting2.png");
	btnPlay = button_create((SCREEN_W / 2) - 32, (SCREEN_H / 2) - 146, 64, 64, "Assets/Buttons/Play.png", "Assets/Buttons/Play2.png");
	btnRestart = button_create((SCREEN_W / 2) - 32, (SCREEN_H / 2) - 32, 64, 64, "Assets/Buttons/replay.png", "Assets/Buttons/replay2.png");
	btnHome = button_create((SCREEN_W / 2) - 32, (SCREEN_H / 2) + 82, 64, 64, "Assets/Buttons/to_home.png", "Assets/Buttons/to_home2.png");
	
	//highscore
	HFile = fopen("Assets/Highscore.txt", "r");
	fgets(hscore, 9, HFile);

	//achievements
	a1FILE = fopen("Assets/Achievement1.txt", "r");
	
	ghosts = (Ghost*)malloc(sizeof(Ghost) * GHOST_NUM);
	
	if(!ghosts){
		game_log("We haven't create any ghosts!\n");
	}
	else {
		for (int i = 0; i < GHOST_NUM; i++) {
			
			game_log("creating ghost %d\n", i);
			ghosts[i] = ghost_create(i);  
			if (!ghosts[i])
				game_abort("error creating ghost\n");
			
		}
	}
	GAME_TICK = 0;
	sandmaptimer = al_create_timer(1.0f / 32);
	if (!sandmaptimer)
		game_abort("Failed to build map timer\n");
	//power bean time
	render_init_screen();
	power_up_timer = al_create_timer(1.0f/64); // 1 tick / sec
	if (!power_up_timer)
		game_abort("Error on create timer\n");

	//invisible bean time
	invisible_timer = al_create_timer(1.0f / 64);
	if (!invisible_timer) //if fail report fail to create timer.
		game_abort("Error on create invisible timer\n");
	//freeze timer
	freeze_speed_timer = al_create_timer(1.0f / 64);
	if (!freeze_speed_timer)
		game_abort("Error on create freeze timer\n");
	return;
}

static void step(void) {
	if (pman->objData.moveCD > 0)
		pman->objData.moveCD -= pman->speed;
	for (int i = 0; i < GHOST_NUM; i++) {
		// important for movement
		if (ghosts[i]->objData.moveCD > 0)
			ghosts[i]->objData.moveCD -= ghosts[i]->speed;
	}
}
static void checkItem(void) {
	int Grid_x = pman->objData.Coord.x, Grid_y = pman->objData.Coord.y;
	if (Grid_y >= basic_map->row_num - 1 || Grid_y <= 0 || Grid_x >= basic_map->col_num - 1 || Grid_x <= 0)
		return;
	// [HACKATHON 1-3]
	// TODO: check which item you are going to eat and use `pacman_eatItem` to deal with it.
	
	switch (basic_map->map[Grid_y][Grid_x])
	{
	case '.':
		pacman_eatItem(pman, basic_map->map[Grid_y][Grid_x]);
		basic_map->beansCount--;
		game_main_Score += 10;
		basic_map->map[Grid_y][Grid_x] = ' ';
		break;
	case 'P':
		pacman_eatItem(pman, basic_map->map[Grid_y][Grid_x]);
		game_main_Score += 100;
		basic_map->map[Grid_y][Grid_x] = ' ';
		if (al_get_timer_started(power_up_timer)) {
			al_set_timer_count(power_up_timer, 0);
			GFlag = 0;
		}
		else {
			al_start_timer(power_up_timer);
		}
		for (int i = 0; i < GHOST_NUM; i++) {
			ghost_toggle_FLEE(ghosts[i], true);
		}
		break;
	case 'D':
		pacman_eatItem(pman, basic_map->map[Grid_y][Grid_x]);
		al_start_timer(invisible_timer);
		game_log("invisible bean start");
		cheat_mode = true;
		IFlag = 1;
		game_main_Score += 100;
		basic_map->map[Grid_y][Grid_x] = ' ';
		break;
	case 'S':
		pacman_eatItem(pman, basic_map->map[Grid_y][Grid_x]);
		al_start_timer(freeze_speed_timer);
		game_log("Freeze bean start");
		FFlag = 1;
		pman->speed = 4;
		game_main_Score += 100;
		basic_map->map[Grid_y][Grid_x] = ' ';
		break;
	default:
		break;
	}
	
	
}
static void status_update(void) {
	for (int i = 0; i < GHOST_NUM; i++) {
		if (ghosts[i]->status == GO_IN)
			continue;

		if (RecAreaOverlap(getDrawArea(pman->objData, GAME_TICK_CD), getDrawArea(ghosts[i]->objData, GAME_TICK_CD)))
		{
			if (ghosts[i]->status != FLEE && !cheat_mode && IFlag==0 && FFlag ==0) {
				game_log("collided with ghost\n");
				al_rest(1.0);
				pacman_die();
				game_over = true;
				al_start_timer(pman->death_anim_counter);
				break;
			}
			else  if(ghosts[i]->status ==FLEE || FFlag==1){
				ghost_collided(ghosts[i]);
				game_main_Score += 100;
			}
		}
		if (basic_map->beansCount == 0) {
			game_win = true;
			break;
		}
	}
}

static void achievement(int type) {
	//time_t rawtime;
	//struct tm* timeinfo;
	//time(&rawtime);
	//receiving in local time from computer
	//statuses 0=locked, 1=unlock, 2=already unlocked
	//timeinfo = localtime(&rawtime);
	a1FILE = fopen("Assets/Achievement1.txt", "ab");
	if (atoi(one_status) == 1 && type == 0) {
		strcpy(one_status, "2");
		fputs(one_status, a1FILE);
		//fputs('\n', a1FILE);
		//fputs(asctime(timeinfo), a1FILE);
	}
	fclose(a1FILE); //close file.
}

static void update(void) {

	if (game_over) {
		game_log("%d", al_get_timer_count(pman->death_anim_counter));
		if (al_get_timer_count(pman->death_anim_counter) >50) {
			game_log("Return to main menu");
			if (atoi(hscore) < atoi(score)) {
				game_log("entered this if");
				HFile = fopen("Assets/Highscore.txt", "w");
				fputs(score, HFile);
				fclose(HFile);
			}
			if (atoi(score) >= 7000 && atoi(one_status) == 0) {
				strcpy(one_status, "1");
				game_log("Achivement unlocked!");
				achievement(0);
			}
			game_change_scene(scene_gameover_create());
			game_log("Lose!");
			game_over = false;
		}

		return;
		
	}
	else if (game_win) {
		if (atoi(hscore) < atoi(score)) {
			game_log("Return to main menu");
			HFile = fopen("Assets/Highscore.txt", "w");
			fputs(score, HFile);
			fclose(HFile);
		}
		if (atoi(score) >= 7000 && atoi(one_status) == 0) {
			strcpy(one_status, "1");
			game_log("Achivement unlocked!");
			achievement(0);
		}
		game_change_scene(scene_win_create());
		game_log("Win!");
		game_win = false;
		return;
	}

	//----------------timers--------------//


	if (al_get_timer_count(power_up_timer) > 448) {
		GFlag = 1;
	}
	if (al_get_timer_count(power_up_timer) > 640) {
		al_stop_timer(power_up_timer);
		al_set_timer_count(power_up_timer, 0);
		GFlag = 0;
		for (int i = 0; i < GHOST_NUM; i++) {
			ghost_toggle_FLEE(ghosts[i], false);
		}
	}
	if (al_get_timer_count(invisible_timer) > 384) {
		cheat_mode = false;
		IFlag = 0;
		game_log("Invisible expired");
		al_stop_timer(invisible_timer);
		al_set_timer_count(invisible_timer, 0);
	}
	if (al_get_timer_count(freeze_speed_timer) > 576) {
		FFlag = 0;
		pman->speed = 2;
		game_log("Freeze expired");
		al_stop_timer(freeze_speed_timer);
		al_set_timer_count(freeze_speed_timer, 0);
	}
		step();
		checkItem();
		status_update();
		if (PFlag == 0) {
			pacman_move(pman, basic_map);
			if (FFlag == 0) {
				for (int i = 0; i < GHOST_NUM; i++) {
					ghosts[i]->move_script(ghosts[i], basic_map, pman);
				}
			}
		}
}



static void draw(void) {
	//backdrop elements
	al_clear_to_color(al_map_rgb(243, 223, 148));
	draw_map(basic_map);
	//scores draw
	sprintf_s(score, 9, "%d", game_main_Score);
	al_draw_text(
		menuFont,
		al_map_rgb(0,0,0),
		SCREEN_W - 100,10,
		ALLEGRO_ALIGN_RIGHT,
		score);
	al_draw_text(menuFont, al_map_rgb(0, 0, 0), 200, 15, ALLEGRO_ALIGN_LEFT, hscore);
	al_draw_text(menuFont, al_map_rgb(0, 0, 0), 25, 15, ALLEGRO_ALIGN_LEFT, "Highscore:");
	pacman_draw(pman);
	//al_draw_bitmap(trophy, 10, 10, 0);

	if (game_over)
		return;
	// no drawing below when game over
	for (int i = 0; i < GHOST_NUM; i++)
		ghost_draw(ghosts[i]);
	
	//debugging mode
	if (debug_mode) {
		draw_hitboxes();
	}
	
	//pausing
	if (PFlag == 0) {
		drawButton(btnPause);
	}

	if (PFlag == 1) {
		drawButton(btnPause);
		al_draw_filled_rectangle(0, 0, 800, 800, al_map_rgba(0, 0, 0,150));
		al_draw_text(headerFont, al_map_rgb(255, 255, 255), SCREEN_W / 2, 70, ALLEGRO_ALIGN_CENTER, "PAUSED");
		drawButton(btnHome);
		drawButton(btnPlay);
		drawButton(btnRestart);
		//drawButton(btnSetting);
	}
}

static void draw_hitboxes(void) {
	RecArea pmanHB = getDrawArea(pman->objData, GAME_TICK_CD);
	al_draw_rectangle(
		pmanHB.x, pmanHB.y,
		pmanHB.x + pmanHB.w, pmanHB.y + pmanHB.h,
		al_map_rgb_f(1.0, 0.0, 0.0), 2
	);

	for (int i = 0; i < GHOST_NUM; i++) {
		RecArea ghostHB = getDrawArea(ghosts[i]->objData, GAME_TICK_CD);
		al_draw_rectangle(
			ghostHB.x, ghostHB.y,
			ghostHB.x + ghostHB.w, ghostHB.y + ghostHB.h,
			al_map_rgb_f(1.0, 0.0, 0.0), 2
		);
	}

}

static void printinfo(void) {
	game_log("pacman:\n");
	game_log("coord: %d, %d\n", pman->objData.Coord.x, pman->objData.Coord.y);
	game_log("PreMove: %d\n", pman->objData.preMove);
	game_log("NextTryMove: %d\n", pman->objData.nextTryMove);
	game_log("Speed: %f\n", pman->speed);
}

static void on_mouse_move(int a, int mouse_x, int mouse_y, int f) {
	if (PFlag == 0) { //button hovering only works when Pause flag is 0.
		btnPause.hovered = buttonHover(btnPause, mouse_x, mouse_y);
	}

	btnPlay.hovered = buttonHover(btnPlay, mouse_x, mouse_y);
	btnHome.hovered = buttonHover(btnHome, mouse_x, mouse_y);
	//btnSetting.hovered = buttonHover(btnSetting, mouse_x, mouse_y);
	btnRestart.hovered = buttonHover(btnRestart, mouse_x, mouse_y);
}

static void on_mouse_down() {
	if (PFlag == 0) { //prevent invisible buttons from working.
		if (btnPause.hovered) {
			PFlag = 1;
			al_stop_timer(invisible_timer);
			al_stop_timer(freeze_speed_timer);
			al_stop_timer(power_up_timer);
		}
	}
	if (PFlag == 1) {
		if (btnPlay.hovered) {
			PFlag = 0;
			if (al_get_timer_started(invisible_timer) == true) {
				al_resume_timer(invisible_timer);
			}
			if (al_get_timer_started(freeze_speed_timer) == true) {
				al_resume_timer(freeze_speed_timer);
			}
			if (al_get_timer_started(power_up_timer) == true) {
				al_resume_timer(power_up_timer);
			}
		}
		if (btnHome.hovered) {
			game_change_scene(scene_menu_create());
		}
		//if (btnSetting.hovered) {
			//game_change_scene(scene_settings_create());
		//}
		if (btnRestart.hovered) {
			game_change_scene(scene_main_create());
		}
	}

}
static void destroy(void) {
	al_destroy_bitmap(btnHome.default_img);
	al_destroy_bitmap(btnHome.hovered_img);
	
	al_destroy_bitmap(btnPause.hovered_img);
	al_destroy_bitmap(btnPause.default_img);
	
	al_destroy_bitmap(btnPlay.default_img);
	al_destroy_bitmap(btnPlay.hovered_img);
	
	al_destroy_bitmap(btnRestart.default_img);
	al_destroy_bitmap(btnRestart.hovered_img);

	al_destroy_bitmap(btnSetting.default_img);
	al_destroy_bitmap(btnSetting.hovered_img);

	al_destroy_timer(invisible_timer);
	al_destroy_timer(freeze_speed_timer);
	al_destroy_timer(power_up_timer);

	al_destroy_bitmap(trophy);

	al_destroy_timer(sandmaptimer);
	free(basic_map);
	free(pman);
	for (int i = 0; i < GHOST_NUM; i++) {
		ghost_destory(ghosts[i]);
	}
	free(ghosts);
	fclose(HFile);

}

static void on_key_down(int key_code) {
	switch (key_code)
	{
		case ALLEGRO_KEY_W:
			pacman_NextMove(pman, UP);
			break;
		case ALLEGRO_KEY_A:
			pacman_NextMove(pman, LEFT);
			break;
		case ALLEGRO_KEY_S:
			pacman_NextMove(pman, DOWN);
			break;
		case ALLEGRO_KEY_D:
			pacman_NextMove(pman, RIGHT);
			break;
		case ALLEGRO_KEY_C:
			cheat_mode = !cheat_mode;
			if (cheat_mode) {
				game_main_Score += 5000;
				//game_over = true;
				printf("cheat mode on\n");
			}
			else 
				printf("cheat mode off\n");
			break;
		case ALLEGRO_KEY_L:
			basic_map->beansCount = 0;
			break;
		case ALLEGRO_KEY_G:
			debug_mode = !debug_mode;
			break;
		case ALLEGRO_KEY_ESCAPE:
			game_log("Pause initiated\n");
			if (PFlag == 0) {
				PFlag = 1;
				al_stop_timer(invisible_timer);
				al_stop_timer(freeze_speed_timer);
				al_stop_timer(power_up_timer);
			}
			else if (PFlag == 1) {
				PFlag = 0;
				if (al_get_timer_started(invisible_timer) ==true) {
					al_resume_timer(invisible_timer);
				}
				if (al_get_timer_started(freeze_speed_timer) == true) {
					al_resume_timer(freeze_speed_timer);
				}
				if (al_get_timer_started(power_up_timer) == true) {
					al_resume_timer(power_up_timer);
				}
			}
			break;
		
	default:
		break;
	}

}

static void render_init_screen(void) {
	al_clear_to_color(al_map_rgb(0, 0, 0));

	draw_map(basic_map);
	pacman_draw(pman);
	for (int i = 0; i < GHOST_NUM; i++) {
		ghost_draw(ghosts[i]);
	}

	al_draw_text(
		menuFont,
		al_map_rgb(0, 0, 0),
		400, 400,
		ALLEGRO_ALIGN_CENTER,
		"READY!"
	);

	al_flip_display();
	al_rest(2.0);

}
// Functions without 'static', 'extern' prefixes is just a normal
// function, they can be accessed by other files using 'extern'.
// Define your normal function prototypes below.

// The only function that is shared across files.
Scene scene_main_create(void) {
	Scene scene;
	memset(&scene, 0, sizeof(Scene));
	scene.name = "Start";
	scene.initialize = &init;
	scene.update = &update;
	scene.draw = &draw;
	scene.destroy = &destroy;
	scene.on_key_down = &on_key_down;
	scene.on_mouse_move = &on_mouse_move;
	scene.on_mouse_down = &on_mouse_down;
	PFlag = 0; //reset pause flag to 0 on game start.
	FFlag = 0;
	IFlag = 0;
	GFlag = 0;


	game_log("Start scene created");
	return scene;
}
