#ifndef SCENE_WIN_H
#define SCENE_WIN_H
//#define _CRT_SECURE_NO_WARNINGS
#include "game.h"

Scene scene_win_create(void);

#endif
