#ifndef SCENE_ACHIEVE_H
#define SCENE_ACHIEVE_H
//#define _CRT_SECURE_NO_WARNINGS
#include "game.h"

Scene scene_achievement_create(void);

#endif
