#define _CRT_SECURE_NO_WARNINGS


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_native_dialog.h>
#include <math.h>
#include "scene_menu_object.h"
#include "scene_settings.h"
#include "scene_game.h"
#include "scene_menu.h"
#include "utility.h"
#include "shared.h"

// Variables and functions with 'static' prefix at the top level of a
// source file is only accessible in that file ("file scope", also
// known as "internal linkage"). If other files has the same variable
// name, they'll be different variables.

/* Define your static vars / function prototypes below. */

// TODO: More variables and functions that will only be accessed
// inside this scene. They should all have the 'static' prefix.
//file settings
static ALLEGRO_SAMPLE_ID achieveBGM;
static Button btnHome;

static ALLEGRO_BITMAP* locked1 = NULL;
static ALLEGRO_BITMAP* unlocked1 = NULL;
static ALLEGRO_TIMER* unlocked1timer;

//achievement 1 functions
extern FILE* a1FILE = NULL;
extern char one_status[128];
char one_date[128];

static void init() {
	stop_bgm(achieveBGM);
	achieveBGM = play_bgm(winMusic, music_volume);
	btnHome = button_create(20, 20, 80, 50, "Assets/Buttons/back.png", "Assets/Buttons/back2.png");

	locked1 = load_bitmap("Assets/Achievements/lockedkills1.png");
	unlocked1 = load_bitmap("Assets/Achievements/kills1.png");

	//read files
	a1FILE = fopen("Assets/Achievement1.txt", "r");
	for (size_t i = 0; i < 2; i++) {
		if (i == 0) fgets(one_status, sizeof(one_status), a1FILE);
		if (i == 1) fgets(one_date, sizeof(one_date), a1FILE);
	}
	game_log("a0: at %s", one_status);
	game_log("a1: at %s", one_date);

	unlocked1timer = al_create_timer(1.0f / 16);
	if (!unlocked1timer) {
		game_abort("error creating achievement timer\n");
	}
	return;

}

static void draw(void ){
	al_clear_to_color(al_map_rgb(0, 0, 0));
	al_draw_text(headerFont, al_map_rgb(255, 255, 255), SCREEN_W / 2, 20, ALLEGRO_ALIGN_CENTER, "ACHIEVEMENT");
	drawButton(btnHome);

	switch (atoi(one_status)) {
	case 0:
		al_draw_text(normalFont, al_map_rgb(255, 255, 255), 109, 160, ALLEGRO_ALIGN_LEFT, "Locked Achievement");
		al_draw_text(smallFont, al_map_rgb(255, 255, 255), 109, 190, ALLEGRO_ALIGN_LEFT, "Obtain 7,000 points or more in a single game.");
		al_draw_bitmap(locked1, 25, 150, 0);
		break;
	case 2:
		al_draw_text(normalFont, al_map_rgb(255, 255, 255), 109, 160, ALLEGRO_ALIGN_LEFT, "VII");
		al_draw_text(smallFont, al_map_rgb(255, 255, 255), 109, 190, ALLEGRO_ALIGN_LEFT, "Obtain 7,000 points or more in a single game.");
		al_start_timer(unlocked1timer);
		if (al_get_timer_count(unlocked1timer) <= 4) {
			al_draw_scaled_bitmap(unlocked1, 0, 0, 64, 64, 25, 150, 64, 64, 0);
		}
		else if (al_get_timer_count(unlocked1timer) <= 8) {
			al_draw_scaled_bitmap(unlocked1, 64, 0, 64, 64, 25, 150, 64, 64, 0);
		}
		else if (al_get_timer_count(unlocked1timer) <= 12) {
			al_draw_scaled_bitmap(unlocked1, 128, 0, 64, 64, 25, 150, 64, 64, 0);
		}
		else if (al_get_timer_count(unlocked1timer) <= 16) {
			al_draw_scaled_bitmap(unlocked1, 192, 0, 64, 64, 25, 150, 64, 64, 0);
		}
		else if (al_get_timer_count(unlocked1timer) <= 20) {
			al_draw_scaled_bitmap(unlocked1, 256, 0, 64, 64, 25, 150, 64, 64, 0);
		}
		else if (al_get_timer_count(unlocked1timer) <= 24) {
			al_draw_scaled_bitmap(unlocked1, 320, 0, 64, 64, 25, 150, 64, 64, 0);
		}
		else if (al_get_timer_count(unlocked1timer) <= 28) {
			al_draw_scaled_bitmap(unlocked1, 384, 0, 64, 64, 25, 150, 64, 64, 0);
		}
		else if (al_get_timer_count(unlocked1timer) > 28) {
			al_draw_scaled_bitmap(unlocked1, 448, 0, 64, 64, 25, 150, 64, 64, 0);
		}
		if (al_get_timer_count(unlocked1timer) > 32) {
			al_set_timer_count(unlocked1timer, 0);
		}
		
		break;
	default:
		break;
	}
}

static void on_mouse_move(int a, int mouse_x, int mouse_y, int f) {
	btnHome.hovered = buttonHover(btnHome, mouse_x, mouse_y);
}

static void on_mouse_down() {
	if (btnHome.hovered) {
		game_change_scene(scene_menu_create());
	}
}

static void destroy() {
	stop_bgm(achieveBGM);
	al_destroy_bitmap(btnHome.default_img);
	al_destroy_bitmap(btnHome.hovered_img);
	al_destroy_bitmap(locked1);
	al_destroy_bitmap(unlocked1);

	al_destroy_timer(unlocked1timer);
}
// The only function that is shared across files.
Scene scene_achievement_create(void) {
	Scene scene;
	memset(&scene, 0, sizeof(Scene));
	scene.name = "Achievement";
	scene.draw = &draw;
	scene.initialize = &init;
	scene.destroy = &destroy;
	//scene.on_key_down = &on_key_down;
	scene.on_mouse_down = &on_mouse_down;
	scene.on_mouse_move = &on_mouse_move;
	// TODO: Register more event callback functions such as keyboard, mouse, ...
	game_log("Achievement scene created");
	return scene;
}