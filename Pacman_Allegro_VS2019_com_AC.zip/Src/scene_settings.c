#define _CRT_SECURE_NO_WARNINGS


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_native_dialog.h>
#include <math.h>
#include "scene_menu_object.h"
#include "scene_settings.h"
#include "scene_game.h"
#include "scene_menu.h"
#include "utility.h"
#include "shared.h"

extern FILE* Preset = NULL;
char Vol[128];
char Fx[128];
char VolTemp[128];
char FxTemp[128];

static ALLEGRO_SAMPLE_ID settingsBGM;
static ALLEGRO_BITMAP* gameBack = NULL;
static ALLEGRO_TIMER* Backtimer;
static Button btnReturn;
static Button btnVolumeUp;
static Button btnVolumeDown;
static ALLEGRO_BITMAP* bar0 = NULL;
static ALLEGRO_BITMAP* bar10 = NULL;
static ALLEGRO_BITMAP* bar20 = NULL;
static ALLEGRO_BITMAP* bar30 = NULL;
static ALLEGRO_BITMAP* bar40 = NULL;
static ALLEGRO_BITMAP* bar50 = NULL;
static ALLEGRO_BITMAP* bar60 = NULL;
static ALLEGRO_BITMAP* bar70 = NULL;
static ALLEGRO_BITMAP* bar80 = NULL;
static ALLEGRO_BITMAP* bar90 = NULL;
static ALLEGRO_BITMAP* bar100 = NULL;

static Button btnFxUp;
static Button btnFxDown;
static ALLEGRO_BITMAP* Fxbar0 = NULL;
static ALLEGRO_BITMAP* Fxbar10 = NULL;
static ALLEGRO_BITMAP* Fxbar20 = NULL;
static ALLEGRO_BITMAP* Fxbar30 = NULL;
static ALLEGRO_BITMAP* Fxbar40 = NULL;
static ALLEGRO_BITMAP* Fxbar50 = NULL;
static ALLEGRO_BITMAP* Fxbar60 = NULL;
static ALLEGRO_BITMAP* Fxbar70 = NULL;
static ALLEGRO_BITMAP* Fxbar80 = NULL;
static ALLEGRO_BITMAP* Fxbar90 = NULL;
static ALLEGRO_BITMAP* Fxbar100 = NULL;

static Button btnSkinLeft;
static Button btnSkinRight;

static void init() {
	//Play music. / backgrounds
	stop_bgm(settingsBGM);
	settingsBGM = play_bgm(themeMusic2, music_volume);
	gameBack = load_bitmap("Assets/Background/beach_2cropped.png");

	//Personalizing settings.
	Preset = fopen("Assets/Settings_presets.txt", "r");
	for (size_t i = 0; i < 2; i++) {
		if (i == 0) {
			fgets(Vol, sizeof(Vol), Preset);
		}
		if (i == 1) {
			fgets(Fx, sizeof(Fx), Preset);
		}
	}
	music_volume = atof(Vol);
	effect_volume = atof(Fx);

	//draw buttons.
	btnReturn = button_create(20, 20, 80, 50, "Assets/Buttons/back.png", "Assets/Buttons/back2.png");
	btnSkinLeft = button_create(200, 200, 40, 40, "Assets/Buttons/decrease.png", "Assets/Buttons/decrease2.png");
	btnSkinRight = button_create(500, 200, 40, 40, "Assets/Buttons/increase.png", "Assets/Buttons/increase2.png");
	//volume buttons & bars
	btnVolumeUp = button_create(610, 397, 40, 40, "Assets/Buttons/increase.png", "Assets/Buttons/increase2.png");
	btnVolumeDown = button_create(152, 397, 40, 40, "Assets/Buttons/decrease.png", "Assets/Buttons/decrease2.png");
	bar0 = load_bitmap("Assets/Bars/bar0.png");
	bar10 = load_bitmap("Assets/Bars/bar10.png");
	bar20 = load_bitmap("Assets/Bars/bar20.png");
	bar30 = load_bitmap("Assets/Bars/bar30.png");
	bar40 = load_bitmap("Assets/Bars/bar40.png");
	bar50 = load_bitmap("Assets/Bars/bar50.png");
	bar60 = load_bitmap("Assets/Bars/bar60.png");
	bar70 = load_bitmap("Assets/Bars/bar70.png");
	bar80 = load_bitmap("Assets/Bars/bar80.png");
	bar90 = load_bitmap("Assets/Bars/bar90.png");
	bar100 = load_bitmap("Assets/Bars/bar100.png");

	//sfx buttons & bars
	btnFxUp = button_create(610, 547, 40, 40, "Assets/Buttons/increase.png", "Assets/Buttons/increase2.png");
	btnFxDown = button_create(152, 547, 40, 40, "Assets/Buttons/decrease.png", "Assets/Buttons/decrease2.png");

	Backtimer = al_create_timer(1.0f / 30);
	if (!Backtimer)
		game_abort("Error on creating background timer\n");
	return;

}

static void draw(void ){
	al_clear_to_color(al_map_rgb(0, 0, 0));
	al_start_timer(Backtimer);
	if (al_get_timer_count(Backtimer) <= 6) {
		al_draw_scaled_bitmap(gameBack, 0, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if ( al_get_timer_count(Backtimer) <= 12) {
		al_draw_scaled_bitmap(gameBack, 800, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if ( al_get_timer_count(Backtimer) <= 18) {
		al_draw_scaled_bitmap(gameBack, 1600, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if (al_get_timer_count(Backtimer) <= 24) {
		al_draw_scaled_bitmap(gameBack, 2400, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if ( al_get_timer_count(Backtimer) <= 30) {
		al_draw_scaled_bitmap(gameBack, 3200, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if ( al_get_timer_count(Backtimer) <= 36) {
		al_draw_scaled_bitmap(gameBack, 4000, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if ( al_get_timer_count(Backtimer) <= 42) {
		al_draw_scaled_bitmap(gameBack, 4800, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if ( al_get_timer_count(Backtimer) <= 48) {
		al_draw_scaled_bitmap(gameBack, 5600, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if ( al_get_timer_count(Backtimer) <= 54) {
		al_draw_scaled_bitmap(gameBack, 6400, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if ( al_get_timer_count(Backtimer) <= 60) {
		al_draw_scaled_bitmap(gameBack, 7200, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if ( al_get_timer_count(Backtimer) <= 66) {
		al_draw_scaled_bitmap(gameBack, 8000, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if ( al_get_timer_count(Backtimer) > 66) {
		al_draw_scaled_bitmap(gameBack, 8800, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	if (al_get_timer_count(Backtimer) > 72) {
		al_set_timer_count(Backtimer, 0);
	}

	al_draw_text(headerFont, al_map_rgb(0, 0, 0), SCREEN_W / 2, 30, ALLEGRO_ALIGN_CENTER, "SETTINGS");
	al_draw_text(menuFont, al_map_rgb(0, 0, 0), SCREEN_W / 2 , (SCREEN_H / 2) - 50, ALLEGRO_ALIGN_CENTER, "Music Volume");
	switch ((int)(20 * music_volume)) {
	case 20:
		al_draw_scaled_bitmap(bar100, 0, 0, 400, 32, 200, SCREEN_H / 2, 400, 32, 0);
		break;
	case 18:
		al_draw_scaled_bitmap(bar90, 0, 0, 400, 32, 200, SCREEN_H / 2, 400, 32, 0);
		break;
	case 16:
		al_draw_scaled_bitmap(bar80, 0, 0, 400, 32, 200, SCREEN_H / 2, 400, 32, 0);
		break;
	case 14:
		al_draw_scaled_bitmap(bar70, 0, 0, 400, 32, 200, SCREEN_H / 2, 400, 32, 0);
		break;
	case 12:
		al_draw_scaled_bitmap(bar60, 0, 0, 400, 32, 200, SCREEN_H / 2, 400, 32, 0);
		break;
	case 10:
		al_draw_scaled_bitmap(bar50, 0, 0, 400, 32, 200, SCREEN_H / 2, 400, 32, 0);
		break;
	case 8:
		al_draw_scaled_bitmap(bar40, 0, 0, 400, 32, 200, SCREEN_H / 2, 400, 32, 0);
		break;
	case 6:
		al_draw_scaled_bitmap(bar30, 0, 0, 400, 32, 200, SCREEN_H / 2, 400, 32, 0);
		break;
	case 4:
		al_draw_scaled_bitmap(bar20, 0, 0, 400, 32, 200, SCREEN_H / 2, 400, 32, 0);
		break;
	case 2:
		al_draw_scaled_bitmap(bar10, 0, 0, 400, 32, 200, SCREEN_H / 2, 400, 32, 0);
		break;
	case 0:
		al_draw_scaled_bitmap(bar0, 0, 0, 400, 32, 200, SCREEN_H / 2, 400, 32, 0);
		break;
	}

	al_draw_text(menuFont, al_map_rgb(0,0,0), SCREEN_W / 2, (SCREEN_H / 2) + 100, ALLEGRO_ALIGN_CENTER, "Effects Volume");
	switch ((int)(20 * effect_volume)) {
	case 20:
		al_draw_scaled_bitmap(bar100, 0, 0, 400, 32, 200, (SCREEN_H /2) +150, 400, 32, 0);
		break;
	case 18:
		al_draw_scaled_bitmap(bar90, 0, 0, 400, 32, 200, (SCREEN_H / 2) + 150, 400, 32, 0);
		break;
	case 16:
		al_draw_scaled_bitmap(bar80, 0, 0, 400, 32, 200, (SCREEN_H / 2) + 150, 400, 32, 0);
		break;
	case 14:
		al_draw_scaled_bitmap(bar70, 0, 0, 400, 32, 200, (SCREEN_H / 2) + 150, 400, 32, 0);
		break;
	case 12:
		al_draw_scaled_bitmap(bar60, 0, 0, 400, 32, 200, (SCREEN_H / 2) + 150, 400, 32, 0);
		break;
	case 10:
		al_draw_scaled_bitmap(bar50, 0, 0, 400, 32, 200, (SCREEN_H / 2) + 150, 400, 32, 0);
		break;
	case 8:
		al_draw_scaled_bitmap(bar40, 0, 0, 400, 32, 200, (SCREEN_H / 2) + 150, 400, 32, 0);
		break;
	case 6:
		al_draw_scaled_bitmap(bar30, 0, 0, 400, 32, 200, (SCREEN_H / 2) + 150, 400, 32, 0);
		break;
	case 4:
		al_draw_scaled_bitmap(bar20, 0, 0, 400, 32, 200, (SCREEN_H / 2) + 150, 400, 32, 0);
		break;
	case 2:
		al_draw_scaled_bitmap(bar10, 0, 0, 400, 32, 200, (SCREEN_H / 2) + 150, 400, 32, 0);
		break;
	case 0:
		al_draw_scaled_bitmap(bar0, 0, 0, 400, 32, 200, (SCREEN_H / 2) + 150, 400, 32, 0);
		break;
	}

	drawButton(btnReturn);
	drawButton(btnVolumeUp);
	drawButton(btnVolumeDown);
	drawButton(btnFxUp);
	drawButton(btnFxDown);
}

static void on_mouse_move(int a, int mouse_x, int mouse_y, int f) {
	btnReturn.hovered = buttonHover(btnReturn, mouse_x, mouse_y);
	btnVolumeUp.hovered = buttonHover(btnVolumeUp, mouse_x, mouse_y);
	btnVolumeDown.hovered = buttonHover(btnVolumeDown, mouse_x, mouse_y);

	btnFxUp.hovered = buttonHover(btnFxUp, mouse_x, mouse_y);
	btnFxDown.hovered = buttonHover(btnFxDown, mouse_x, mouse_y);

}
static void volume_update() { //new function to keep track of volume, save up writing lines. 
	Preset = fopen("Assets/Settings_presets.txt", "w");
	sprintf_s(VolTemp, 128, "%f\n", music_volume);
	sprintf_s(FxTemp, 128, "%f\n", effect_volume);
	fputs(VolTemp, Preset);
	fputs(FxTemp, Preset);
	fclose(Preset);
}

static void on_mouse_down() {
	if (btnReturn.hovered) {
		/*Preset = fopen("Assets/Settings_presets.txt", "w");
		sprintf_s(VolTemp, 128, "%f\n", music_volume);
		sprintf_s(FxTemp, 128, "%f\n", effect_volume);
		fputs(VolTemp, Preset);
		fputs(FxTemp, Preset);
		fclose(Preset);*/
		game_change_scene(scene_menu_create());
	}
	//music volume. and saving settings presets.
	if (btnVolumeDown.hovered && music_volume > 0) {
		music_volume -= 0.1;
		/*Preset = fopen("Assets/Settings_presets.txt", "w");
		sprintf_s(VolTemp, 128, "%f\n", music_volume);
		sprintf_s(FxTemp, 128, "%f\n", effect_volume);
		fputs(VolTemp, Preset);
		fputs(FxTemp, Preset);
		fclose(Preset);*/
		volume_update();
		stop_bgm(settingsBGM);
		settingsBGM = play_bgm(themeMusic2, music_volume);
	}

	if (btnVolumeUp.hovered && music_volume < 1) {
		music_volume += 0.1;
		/*Preset = fopen("Assets/Settings_presets.txt", "w");
		sprintf_s(VolTemp, 128, "%f\n", music_volume);
		sprintf_s(FxTemp, 128, "%f\n", effect_volume);
		fputs(VolTemp, Preset);
		fputs(FxTemp, Preset);
		fclose(Preset);*/
		volume_update();
		stop_bgm(settingsBGM);
		settingsBGM = play_bgm(themeMusic2, music_volume);
	}

	if (btnFxDown.hovered && effect_volume > 0) {
		effect_volume -= 0.1;
		volume_update();
		/*Preset = fopen("Assets/Settings_presets.txt", "w");
		sprintf_s(VolTemp, 128, "%f\n", music_volume);
		sprintf_s(FxTemp, 128, "%f\n", effect_volume);
		fputs(VolTemp, Preset);
		fputs(FxTemp, Preset);
		fclose(Preset);*/
	}

	if (btnFxUp.hovered && effect_volume < 1) {
		effect_volume += 0.1;
		volume_update();
		/*Preset = fopen("Assets/Settings_presets.txt", "w");
		sprintf_s(VolTemp, 128, "%f\n", music_volume);
		sprintf_s(FxTemp, 128, "%f\n", effect_volume);
		fputs(VolTemp, Preset);
		fputs(FxTemp, Preset);
		fclose(Preset);*/
	}
}

static void destroy() {
	stop_bgm(settingsBGM);
	al_destroy_bitmap(btnReturn.default_img);
	al_destroy_bitmap(btnReturn.hovered_img);

	al_destroy_bitmap(btnVolumeUp.default_img);
	al_destroy_bitmap(btnVolumeUp.hovered_img);
	al_destroy_bitmap(btnVolumeDown.default_img);
	al_destroy_bitmap(btnVolumeDown.hovered_img);

	al_destroy_bitmap(btnFxUp.default_img);
	al_destroy_bitmap(btnFxUp.hovered_img);
	al_destroy_bitmap(btnFxDown.default_img);
	al_destroy_bitmap(btnFxDown.hovered_img);

	al_destroy_bitmap(bar0);
	al_destroy_bitmap(bar10);
	al_destroy_bitmap(bar20);
	al_destroy_bitmap(bar30);
	al_destroy_bitmap(bar40);
	al_destroy_bitmap(bar50);
	al_destroy_bitmap(bar60);
	al_destroy_bitmap(bar70);
	al_destroy_bitmap(bar80);
	al_destroy_bitmap(bar90);
	al_destroy_bitmap(bar100);

	al_destroy_bitmap(gameBack);
	al_destroy_timer(Backtimer);
}
// The only function that is shared across files.
Scene scene_settings_create(void) {
	Scene scene;
	memset(&scene, 0, sizeof(Scene));
	scene.name = "Settings";
	scene.draw = &draw;
	scene.initialize = &init;
	scene.destroy = &destroy;
	//scene.on_key_down = &on_key_down;
	scene.on_mouse_down = &on_mouse_down;
	scene.on_mouse_move = &on_mouse_move;
	scene.volume_update = &volume_update;
	// TODO: Register more event callback functions such as keyboard, mouse, ...
	game_log("Settings scene created");
	return scene;
}