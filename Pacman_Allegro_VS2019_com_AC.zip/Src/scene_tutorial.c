#define _CRT_SECURE_NO_WARNINGS


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_native_dialog.h>
#include <math.h>
#include "scene_menu_object.h"
#include "scene_settings.h"
#include "scene_game.h"
#include "scene_menu.h"
#include "utility.h"
#include "shared.h"

// Variables and functions with 'static' prefix at the top level of a
// source file is only accessible in that file ("file scope", also
// known as "internal linkage"). If other files has the same variable
// name, they'll be different variables.

/* Define your static vars / function prototypes below. */

// TODO: More variables and functions that will only be accessed
// inside this scene. They should all have the 'static' prefix.
//file settings
static ALLEGRO_SAMPLE_ID achieveBGM;
static Button btnHome;
static ALLEGRO_BITMAP* powerbean;
static ALLEGRO_BITMAP* invisiblebean;
static ALLEGRO_BITMAP* freezebean;

static void init() {
	stop_bgm(achieveBGM);
	achieveBGM = play_bgm(themeMusic2, music_volume);
	btnHome = button_create(20, 20, 80, 50, "Assets/Buttons/back.png", "Assets/Buttons/back2.png");
	powerbean = load_bitmap("Assets/Pics/powernuts.png");
	invisiblebean = load_bitmap("Assets/Pics/invisible_mush.png");
	freezebean = load_bitmap("Assets/Pics/freezenuts.png");

}

static void draw(void ){
	al_clear_to_color(al_map_rgb(0, 0, 0));
	al_draw_text(headerFont, al_map_rgb(255, 255, 255), SCREEN_W / 2, 20, ALLEGRO_ALIGN_CENTER, "TUTORIAL");
	drawButton(btnHome);
	al_draw_text(menuFont, al_map_rgb(255, 255, 255), 30, 120, ALLEGRO_ALIGN_LEFT, "Bean Types:");

	al_draw_scaled_bitmap(powerbean, 0, 0, 21, 21, 30, 170, 63, 63, 0);
	al_draw_text(normalFont, al_map_rgb(255, 255, 255), 110, 180, ALLEGRO_ALIGN_LEFT, "Power Bean");
	al_draw_text(smallFont, al_map_rgb(255, 255, 255), 110, 210, ALLEGRO_ALIGN_LEFT, "Scare the ghosts for 10 seconds. You have the ability to eat ghosts while the bean is active.");

	al_draw_scaled_bitmap(invisiblebean, 0, 0, 21, 21, 30, 260, 63, 63, 0);
	al_draw_text(normalFont, al_map_rgb(255, 255, 255), 110, 270, ALLEGRO_ALIGN_LEFT, "Invisibility Mushroom");
	al_draw_text(smallFont, al_map_rgb(255, 255, 255), 110, 300, ALLEGRO_ALIGN_LEFT, "You have the ability to walk through ghosts while the bean is active. Lasts for 6 seconds.");

	al_draw_scaled_bitmap(freezebean, 0, 0, 21, 21, 30, 350, 63, 63, 0);
	al_draw_text(normalFont, al_map_rgb(255, 255, 255), 110, 360, ALLEGRO_ALIGN_LEFT, "Freeze Bean");
	al_draw_text(smallFont, al_map_rgb(255, 255, 255), 110, 390, ALLEGRO_ALIGN_LEFT, "Freeze all ghosts for 9 seconds, while increasing your speed."); 
	al_draw_text(smallFont, al_map_rgb(255, 255, 255), 110, 410, ALLEGRO_ALIGN_LEFT, "You may eat ghosts while the ability is active.");
}

static void on_mouse_move(int a, int mouse_x, int mouse_y, int f) {
	btnHome.hovered = buttonHover(btnHome, mouse_x, mouse_y);
}

static void on_mouse_down() {
	if (btnHome.hovered) {
		game_change_scene(scene_menu_create());
	}
}

static void destroy() {
	stop_bgm(achieveBGM);
	al_destroy_bitmap(btnHome.default_img);
	al_destroy_bitmap(btnHome.hovered_img);
	al_destroy_bitmap(powerbean);
	al_destroy_bitmap(invisiblebean);
	al_destroy_bitmap(freezebean);

}
// The only function that is shared across files.
Scene scene_tutorial_create(void) {
	Scene scene;
	memset(&scene, 0, sizeof(Scene));
	scene.name = "Tutorial";
	scene.draw = &draw;
	scene.initialize = &init;
	scene.destroy = &destroy;
	//scene.on_key_down = &on_key_down;
	scene.on_mouse_down = &on_mouse_down;
	scene.on_mouse_move = &on_mouse_move;
	// TODO: Register more event callback functions such as keyboard, mouse, ...
	game_log("Tutorial scene created");
	return scene;
}