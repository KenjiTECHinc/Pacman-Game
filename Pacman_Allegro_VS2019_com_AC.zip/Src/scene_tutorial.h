#ifndef SCENE_TUTOR_H
#define SCENE_TUTOR_H
//#define _CRT_SECURE_NO_WARNINGS
#include "game.h"

Scene scene_tutorial_create(void);

#endif
