// [HACKATHON 3-9]
// TODO: Create scene_settings.h and scene_settings.c.
// No need to do anything for this part. We've already done it for
// you, so this 2 files is like the default scene template.
#define _CRT_SECURE_NO_WARNINGS


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_native_dialog.h>
#include <math.h>
#include "scene_menu_object.h"
#include "scene_settings.h"
#include "scene_game.h"
#include "scene_menu.h"
#include "utility.h"
#include "shared.h"

static ALLEGRO_SAMPLE_ID loseBGM;
static Button btnReplay;
static Button btnHome;
char hscore[9];
char score[9];
FILE* HFile;
//FILE* HFile;


static void init() {
	stop_bgm(loseBGM);
	loseBGM = play_bgm(themeMusic2, music_volume);

	btnHome = button_create((SCREEN_W / 2) + 70, (SCREEN_H / 2) +100, 64, 64, "Assets/Buttons/to_home.png", "Assets/Buttons/to_home2.png");
	btnReplay = button_create((SCREEN_W / 2) - 134, (SCREEN_H / 2) +100, 64, 64, "Assets/Buttons/replay.png", "Assets/Buttons/replay2.png");

	HFile = fopen("Assets/Highscore.txt", "r");
	fgets(hscore, 9, HFile);
}

static void draw(void ){
	al_clear_to_color(al_map_rgb(0, 0, 0));
	al_draw_text(hugeFont, al_map_rgb(255, 255, 255), SCREEN_W / 2 , 200, ALLEGRO_ALIGN_CENTER, "GAME OVER");
	drawButton(btnHome);
	drawButton(btnReplay);
	al_draw_text(menuFont, al_map_rgb(255, 223, 0), (SCREEN_W/2)+200, 300, ALLEGRO_ALIGN_RIGHT, hscore);
	al_draw_text(menuFont, al_map_rgb(255, 255, 255), (SCREEN_W / 2) - 200, 300, ALLEGRO_ALIGN_LEFT, "Highscore:");
	al_draw_text(menuFont, al_map_rgb(255, 255, 255), (SCREEN_W / 2) + 200, 350, ALLEGRO_ALIGN_RIGHT, score);
	al_draw_text(menuFont, al_map_rgb(255, 255, 255), (SCREEN_W / 2) - 145, 350, ALLEGRO_ALIGN_LEFT, "Score:");
	/*
	if (score >= hscore) {
		al_draw_text(menuFont, al_map_rgb(255, 223, 0), SCREEN_W / 2, 250, ALLEGRO_ALIGN_CENTER, "New Highscore! Congratulations!");
	}*/
}

static void on_mouse_move(int a, int mouse_x, int mouse_y, int f) {
	btnHome.hovered = buttonHover(btnHome, mouse_x, mouse_y);
	btnReplay.hovered = buttonHover(btnReplay, mouse_x, mouse_y);


}

static void on_mouse_down() {
	if (btnHome.hovered) {
		game_change_scene(scene_menu_create());
	}
	if (btnReplay.hovered) {
		game_change_scene(scene_main_create());
	}
	//music volume. and saving settings presets.

}

static void destroy() {
	stop_bgm(loseBGM);
	al_destroy_bitmap(btnHome.default_img);
	al_destroy_bitmap(btnHome.hovered_img);
	al_destroy_bitmap(btnReplay.default_img);
	al_destroy_bitmap(btnReplay.hovered_img);
	fclose(HFile);

}
// The only function that is shared across files.
Scene scene_gameover_create(void) {
	Scene scene;
	memset(&scene, 0, sizeof(Scene));
	scene.name = "Gameover";
	scene.draw = &draw;
	scene.initialize = &init;
	scene.destroy = &destroy;
	//scene.on_key_down = &on_key_down;
	scene.on_mouse_down = &on_mouse_down;
	scene.on_mouse_move = &on_mouse_move;
	// TODO: Register more event callback functions such as keyboard, mouse, ...
	game_log("Gameover scene created");
	return scene;
}