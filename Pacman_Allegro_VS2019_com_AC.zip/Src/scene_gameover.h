#ifndef SCENE_GAMEOVER_H
#define SCENE_GAMEOVER_H
//#define _CRT_SECURE_NO_WARNINGS
#include "game.h"

Scene scene_gameover_create(void);

#endif
