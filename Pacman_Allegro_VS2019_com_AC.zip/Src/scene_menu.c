#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_native_dialog.h>
#include <math.h>
#include "scene_menu_object.h"
#include "scene_settings.h"
#include "scene_game.h"
#include "scene_menu.h"
#include "utility.h"
#include "shared.h"
#include "scene_gameover.h"
#include "scene_win.h"
#include "scene_achievement.h"
#include "scene_tutorial.h"

/* Internal Variables*/
FILE* Preset;
char Vol[128];
char Fx[128];

static ALLEGRO_BITMAP* gameTitle = NULL;
static ALLEGRO_BITMAP* gameBack = NULL;
static ALLEGRO_SAMPLE_ID menuBGM;
static int gameTitleW ;
static int gameTitleH ;
static ALLEGRO_TIMER* Fonttimer;
static ALLEGRO_TIMER* Backtimer;

//dropdown buttons
static int DFlag=0;
static Button btnThreeLines; //toggle to drop down
static Button btnSettings;
static Button btnReturnDrop;
static Button btnQuit;
static Button btnAchievement;
static Button btnTutor;

static void init() {
	//setup font timer to count blinking time
	Fonttimer = al_create_timer(1.0f / 32);
	if (!Fonttimer) {
		game_abort("Failed to create start timer\n");
	}

	//volume adjust to saved preference
	Preset = fopen("Assets/Settings_presets.txt", "r");
	for (size_t i = 0; i < 2; i++) {
		if (i == 0) {
			fgets(Vol, sizeof(Vol), Preset);
		}
		if (i == 1) {
			fgets(Fx, sizeof(Fx), Preset);
		}
	}
	//setting volumes.
	music_volume = atof(Vol);
	effect_volume = atof(Fx);

	//music
	stop_bgm(menuBGM);

	menuBGM = play_bgm(themeMusic2, music_volume);

	//buttons setup
	btnSettings = button_create(730, 80, 40, 40, "Assets/Buttons/setting.png", "Assets/Buttons/setting2.png");
	btnThreeLines = button_create(730, 20, 40, 40, "Assets/Buttons/drop_down.png", "Assets/Buttons/drop_down-2.png");
	btnReturnDrop = button_create(730, 20, 40, 40, "Assets/Buttons/drop_down2.png", "Assets/Buttons/drop_down2-2.png");
	btnQuit = button_create(730, 200, 40, 40, "Assets/Buttons/exit.png", "Assets/Buttons/exit2.png");
	btnAchievement = button_create(730, 140, 40, 40, "Assets/Buttons/achievement.png", "Assets/Buttons/achievement2.png");
	btnTutor = button_create(30, 20, 40, 40, "Assets/Buttons/tutorial.png", "Assets/Buttons/tutorial2.png");

	//arts
	gameTitle = load_bitmap("Assets/title.png");
	gameTitleW = al_get_bitmap_width(gameTitle);
	gameTitleH = al_get_bitmap_height(gameTitle);
	gameBack = load_bitmap("Assets/Background/beach_2cropped.png");
	
	Backtimer = al_create_timer(1.0f / 30);
	if (!Backtimer)
		game_abort("Error on creating background timer\n");
	return;

}


static void draw() {

	al_clear_to_color(al_map_rgb(0, 0, 0));
	al_start_timer(Backtimer);
	if (al_get_timer_count(Backtimer) <= 6) {
		al_draw_scaled_bitmap(gameBack, 0, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if (/*al_get_timer_count(Backtimer) > 6 &&*/ al_get_timer_count(Backtimer) <= 12) {
		al_draw_scaled_bitmap(gameBack, 800, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if (/*al_get_timer_count(Backtimer) > 12 &&*/ al_get_timer_count(Backtimer) <= 18) {
		al_draw_scaled_bitmap(gameBack, 1600, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if (/*al_get_timer_count(Backtimer) > 18 && */al_get_timer_count(Backtimer) <= 24) {
		al_draw_scaled_bitmap(gameBack, 2400, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if (/*al_get_timer_count(Backtimer) > 24 &&*/ al_get_timer_count(Backtimer) <= 30) {
		al_draw_scaled_bitmap(gameBack, 3200, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if (/*al_get_timer_count(Backtimer) > 30 &&*/ al_get_timer_count(Backtimer) <= 36) {
		al_draw_scaled_bitmap(gameBack, 4000, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if (/*al_get_timer_count(Backtimer) > 36 &&*/ al_get_timer_count(Backtimer) <= 42) {
		al_draw_scaled_bitmap(gameBack, 4800, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if (/*al_get_timer_count(Backtimer) > 42 &&*/ al_get_timer_count(Backtimer) <= 48) {
		al_draw_scaled_bitmap(gameBack, 5600, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if (/*al_get_timer_count(Backtimer) > 48 &&*/ al_get_timer_count(Backtimer) <= 54) {
		al_draw_scaled_bitmap(gameBack, 6400, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if (/*al_get_timer_count(Backtimer) > 54 &&*/ al_get_timer_count(Backtimer) <= 60) {
		al_draw_scaled_bitmap(gameBack, 7200, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if (/*al_get_timer_count(Backtimer) > 60 &&*/ al_get_timer_count(Backtimer) <= 66) {
		al_draw_scaled_bitmap(gameBack, 8000, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	else if (/*al_get_timer_count(Backtimer) > 66 &&*/ al_get_timer_count(Backtimer) > 66) {
		al_draw_scaled_bitmap(gameBack, 8800, 0, 800, 800, 0, 0, 800, 800, 0);
	}
	if (al_get_timer_count(Backtimer) > 72) {
		al_set_timer_count(Backtimer, 0);
	}

	const float scale = 0.7;
	const float offset_w = (SCREEN_W >> 1) - 0.5 * scale * gameTitleW;
	const float offset_h = (SCREEN_H >> 1) - 0.5 * scale * gameTitleH;

	//draw title image
	al_draw_scaled_bitmap(
		gameTitle,
		0, 0,
		gameTitleW, gameTitleH,
		offset_w, offset_h,
		gameTitleW * scale, gameTitleH * scale,
		0
	);
	//Font timer to get a blinking effect. print while within time frame, outside time frame no print, once reach timeframe again restart timer.
	al_start_timer(Fonttimer);
	if (al_get_timer_count(Fonttimer) <= 16) {
		al_draw_text(
			menuFont,
			al_map_rgb(0,0,0),
			SCREEN_W / 2,
			SCREEN_H - 150,
			ALLEGRO_ALIGN_CENTER,
			"PRESS \"ENTER\""
		);
	}
	else if (al_get_timer_count(Fonttimer) > 32) {
		al_set_timer_count(Fonttimer, 0);
	}

//draw buttons
	drawButton(btnTutor);
	if (DFlag == 0) {
		drawButton(btnThreeLines);
	}
	if (DFlag == 1) {
		drawButton(btnReturnDrop);
		drawButton(btnQuit);
		drawButton(btnSettings);
		drawButton(btnAchievement);	
	}
}

static void on_mouse_move(int a, int mouse_x, int mouse_y, int f) {
	//button moves
		 btnSettings.hovered = buttonHover(btnSettings, mouse_x, mouse_y);
		 btnThreeLines.hovered = buttonHover(btnThreeLines, mouse_x, mouse_y);
		 btnReturnDrop.hovered = buttonHover(btnReturnDrop, mouse_x, mouse_y);
		 btnQuit.hovered = buttonHover(btnQuit, mouse_x, mouse_y);
		 btnAchievement.hovered = buttonHover(btnAchievement, mouse_x, mouse_y);
		 btnTutor.hovered = buttonHover(btnTutor, mouse_x, mouse_y);
}


static void on_mouse_down() {
	if (btnTutor.hovered) {
		game_change_scene(scene_tutorial_create());
	}
	if (btnThreeLines.hovered) { //prevent invisible buttons from working.
		if (DFlag == 0) {
			DFlag = 1;
		}
		else if (DFlag == 1) {
			DFlag = 0;

		}
	}
	if (DFlag == 1) {
		if (btnSettings.hovered) {
			game_change_scene(scene_settings_create());
		}
		if (btnQuit.hovered) {
			gameDone = true;
		}
		if (btnAchievement.hovered) {
			game_change_scene(scene_achievement_create());
		}
	}
}


static void destroy() {
	stop_bgm(menuBGM);

	al_destroy_bitmap(gameTitle);
	al_destroy_timer(Fonttimer);
	
	al_destroy_bitmap(btnSettings.default_img);
	al_destroy_bitmap(btnSettings.hovered_img);
	
	al_destroy_bitmap(btnReturnDrop.hovered_img);
	al_destroy_bitmap(btnReturnDrop.default_img);

	al_destroy_bitmap(btnThreeLines.hovered_img);
	al_destroy_bitmap(btnThreeLines.default_img);
	
	al_destroy_bitmap(btnQuit.default_img);
	al_destroy_bitmap(btnQuit.hovered_img);

	al_destroy_bitmap(btnAchievement.default_img);
	al_destroy_bitmap(btnAchievement.hovered_img);

	al_destroy_bitmap(btnTutor.default_img);
	al_destroy_bitmap(btnTutor.hovered_img);

	al_destroy_bitmap(gameBack);
	al_destroy_timer(Backtimer);
}

static void on_key_down(int keycode) {

	switch (keycode) {
		case ALLEGRO_KEY_ENTER:
			game_change_scene(scene_main_create());
			break;
		case ALLEGRO_KEY_Q:
			gameDone = true;
			break;
		case ALLEGRO_KEY_E:
			game_change_scene(scene_settings_create());
			break;
		default:
			break;
	}
}


Scene scene_menu_create(void) {

	Scene scene;
	memset(&scene, 0, sizeof(Scene));
	scene.name = "Menu";
	scene.initialize = &init;
	scene.draw = &draw;
	scene.destroy = &destroy;
	scene.on_key_down = &on_key_down;
	scene.on_mouse_move = &on_mouse_move;
	scene.on_mouse_down = &on_mouse_down;
	DFlag = 0; //reset flag back to 0 on screen start




	// TODO: Register more event callback functions such as keyboard, mouse, ...
	game_log("Menu scene created");
	return scene;
}